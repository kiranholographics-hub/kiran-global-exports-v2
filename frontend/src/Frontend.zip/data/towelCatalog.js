const image = (category, slug) => `/images/towels/${category}/${slug}.jpg`;
const thumb = (category, slug) =>
  `/images/towels/${category}/${slug}-thumb.jpg`;

// ---------------------------------------------------------------------------
// Product copy note (Sept 2026 SEO/content audit):
// Specs left as "[Confirm with Mundada]" are real gaps, not filler —
// GSM, size, MOQ and construction need to come from the mill before these
// go live. Filling in a plausible-sounding number instead of the real one
// is worse than leaving the gap visible, since a serious buyer checks
// these against the physical sample. Replace every bracketed placeholder
// with the confirmed figure before publishing.
// ---------------------------------------------------------------------------

const albumTowelProducts = [
  {
    id: "bath-towel",
    slug: "bath-towel",
    name: "Cotton Bath Towel",
    category: "towels",
    subcategory: "bath-towels",
    shortDescription: "Everyday ringspun cotton bath towel for hospitality and retail programmes.",
    description:
      "A ringspun cotton terry bath towel built for repeat commercial washing without losing softness or absorbency. Suited to hotel amenity programmes, retail ranges and private-label development.",
    material: "100% ringspun cotton terry",
    gsm: "[Confirm with Mundada]",
    size: "[Confirm with Mundada]",
    colors: ["White", "Ivory", "[Confirm with Mundada]"],
    construction: "Ringspun cotton terry, dobby border",
    applications: ["Hospitality", "Retail", "Home"],
    customization:
      "Size, colour, border and private-label options available on request.",
    moq: "[Confirm with Mundada]",
    images: [image("bath", "bath-towel"), image("bath", "bath-towel-2")],
    imageThumbs: [thumb("bath", "bath-towel"), thumb("bath", "bath-towel-2")],
    featured: true,
    tags: ["bath", "terry"],
    alt: "Premium cotton bath towel from Kiran Global Exports",
  },
  {
    id: "bath-sheet",
    slug: "bath-sheet",
    name: "Cotton Bath Sheet · 60 × 120 cm",
    category: "towels",
    subcategory: "bath-sheets",
    shortDescription: "Oversized 60 × 120 cm, 400 GSM cotton bath sheet for hospitality and spa.",
    description:
      "A full-size bath sheet at 60 × 120 cm and 400 GSM — larger coverage than a standard bath towel, developed for hospitality, spa and premium retail programmes.",
    material: "100% cotton terry",
    gsm: "400 GSM",
    size: "60 × 120 cm",
    colors: ["White", "Ivory", "[Confirm with Mundada]"],
    construction: "Cotton terry, dobby border",
    applications: ["Hospitality", "Spa", "Retail"],
    customization:
      "Colour, size and private-label development available on request.",
    moq: "[Confirm with Mundada]",
    images: [image("bath-sheets", "bath-sheet")],
    imageThumbs: [thumb("bath-sheets", "bath-sheet")],
    featured: true,
    tags: ["bath-sheet", "400-gsm"],
    alt: "Cotton bath sheet in a 60 by 120 centimetre format",
  },
  {
    id: "hotel-border-towel",
    slug: "hotel-border-towel",
    name: "Hotel Border Towel",
    category: "towels",
    subcategory: "hotel-towels",
    shortDescription: "Dobby-border cotton towel developed for hotel and resort presentation.",
    description:
      "A bordered cotton towel developed for hotel, resort and hospitality collections where a clean, uniform presentation across large repeat orders matters.",
    material: "100% cotton terry",
    gsm: "[Confirm with Mundada]",
    size: "[Confirm with Mundada]",
    colors: ["White", "Ivory", "[Confirm with Mundada]"],
    construction: "Dobby border",
    applications: ["Hospitality", "Hotels", "Resorts"],
    customization:
      "Custom border, size, colour and branding available on request.",
    moq: "[Confirm with Mundada]",
    images: [image("hotel", "hotel-border-towel")],
    imageThumbs: [thumb("hotel", "hotel-border-towel")],
    featured: true,
    tags: ["hotel", "border"],
    alt: "Bordered hotel towel for hospitality collection development",
  },
  {
    id: "jacquard-towel",
    slug: "jacquard-towel",
    name: "Jacquard Cotton Towel",
    category: "towels",
    subcategory: "jacquard-towels",
    shortDescription: "Woven jacquard-pattern cotton towel for retail and private-label ranges.",
    description:
      "A jacquard-woven cotton towel with a patterned border built into the weave rather than printed — a durable, premium presentation for retail and private-label programmes.",
    material: "100% cotton, jacquard weave",
    gsm: "[Confirm with Mundada]",
    size: "[Confirm with Mundada]",
    colors: ["White", "Ivory", "[Confirm with Mundada]"],
    construction: "Jacquard weave",
    applications: ["Hospitality", "Retail", "Private label"],
    customization:
      "Custom jacquard artwork, size, colour and branding available on request.",
    moq: "[Confirm with Mundada]",
    images: [
      image("jacquard", "jacquard-towel"),
      image("jacquard", "jacquard-towel-detail"),
    ],
    imageThumbs: [
      thumb("jacquard", "jacquard-towel"),
      thumb("jacquard", "jacquard-towel-detail"),
    ],
    featured: true,
    tags: ["jacquard", "pattern"],
    alt: "Premium jacquard towel with woven pattern detail",
  },
  {
    id: "waffle-towel",
    slug: "waffle-weave-towel",
    name: "Waffle Weave Cotton Towel",
    category: "towels",
    subcategory: "waffle-towels",
    shortDescription: "Textured waffle-weave towel — lightweight, fast-drying, spa-oriented.",
    description:
      "A waffle-weave cotton towel, including a one-side waffle terry construction. The open weave dries faster and packs flatter than standard terry, suited to spa, wellness and boutique retail ranges.",
    material: "100% cotton, waffle weave",
    gsm: "[Confirm with Mundada]",
    size: "[Confirm with Mundada]",
    colors: ["White", "Ivory", "[Confirm with Mundada]"],
    construction: "Waffle weave / one-side waffle terry",
    applications: ["Spa", "Hospitality", "Retail"],
    customization:
      "Custom size, colour, branding and packaging available on request.",
    moq: "[Confirm with Mundada]",
    images: [
      image("waffle", "waffle-weave-towel"),
      image("waffle", "waffle-terry-detail"),
    ],
    imageThumbs: [
      thumb("waffle", "waffle-weave-towel"),
      thumb("waffle", "waffle-terry-detail"),
    ],
    featured: true,
    tags: ["waffle", "spa"],
    alt: "Waffle weave towel with tactile textured surface",
  },
  {
    id: "zero-twist-towel",
    slug: "zero-twist-towel",
    name: "Zero Twist Cotton Bath Towel",
    category: "towels",
    subcategory: "zero-twist-towels",
    shortDescription:
      "In zero twist yarn the cotton fibres are held together without the usual spinning twist — noticeably softer, faster-absorbing and quicker-drying than conventionally spun terry of the same weight.",
    description:
      "In zero twist yarn the cotton fibres are held together without the usual spinning twist. The towel feels noticeably softer in the hand, absorbs faster than a conventionally spun towel of the same weight, and dries quicker because the pile holds less water in the yarn core. This is a premium retail and boutique hospitality product — it is not built for heavy industrial tunnel washing. If your programme is high-volume hotel laundry, our pure white or plain-dyed terry is the better fit, and we will say so.",
    material: "Zero twist cotton yarn pile, ring spun ground",
    gsm: "[Confirm with Mundada]",
    size: "[Confirm with Mundada]",
    colors: ["Piece dyed", "Pantone matching available"],
    construction: "Zero twist cotton yarn pile, ring spun ground",
    applications: ["Retail", "Spa", "Hospitality"],
    customization:
      "Woven label, satin label, heat transfer or embroidery. Custom size, weight, colour and private-label options available on request.",
    moq: "[Confirm with Mundada]",
    bestFor: "Retail brands, boutique hotels, spa and wellness, premium private-label programmes, gifting.",
    packing: "Bulk carton, individual polybag, belly band or gift box.",
    images: [image("zero-twist", "zero-twist-towel")],
    imageThumbs: [thumb("zero-twist", "zero-twist-towel")],
    featured: true,
    tags: ["zero-twist", "soft-hand"],
    alt: "Soft zero twist cotton bath towel from Kiran Global Exports",
  },
  {
    id: "greek-border-towel",
    slug: "greek-border-towel",
    name: "Greek Border Towel · 50 × 100 cm",
    category: "towels",
    subcategory: "dobby-border-towels",
    shortDescription: "Greek-key dobby border towel, 50 × 100 cm format.",
    description:
      "A Greek-key dobby border towel in a 50 × 100 cm format — a classic hospitality border pattern woven into the towel, developed for hotel and retail collections.",
    material: "100% cotton terry",
    gsm: "[Confirm with Mundada]",
    size: "50 × 100 cm",
    colors: ["White", "Ivory", "[Confirm with Mundada]"],
    construction: "Greek border, dobby weave",
    applications: ["Hospitality", "Retail", "Private label"],
    customization:
      "Custom border artwork, colours and branding available on request.",
    moq: "[Confirm with Mundada]",
    images: [
      image("dobby-border", "greek-border-towel"),
      image("dobby-border", "three-line-border-towel"),
    ],
    imageThumbs: [
      thumb("dobby-border", "greek-border-towel"),
      thumb("dobby-border", "three-line-border-towel"),
    ],
    featured: true,
    tags: ["border", "50x100"],
    alt: "Greek border towel in a 50 by 100 centimetre format",
  },
  {
    id: "pool-towel",
    slug: "pool-towel",
    name: "Pool & Beach Towel",
    category: "towels",
    subcategory: "pool-beach-towels",
    shortDescription: "Striped cotton pool and beach towel for resort and leisure ranges.",
    description:
      "A pool and beach towel developed for resort, leisure and cabana programmes — striped or solid colourways available, built for frequent commercial laundering.",
    material: "100% cotton terry",
    gsm: "[Confirm with Mundada]",
    size: "[Confirm with Mundada]",
    colors: ["[Confirm with Mundada — striped and solid colourways available]"],
    construction: "Cotton terry",
    applications: ["Resorts", "Hospitality", "Leisure"],
    customization:
      "Custom stripes, colourways, size and branding available on request.",
    moq: "[Confirm with Mundada]",
    images: [
      image("pool-beach", "pool-towel"),
      image("pool-beach", "beach-towel"),
    ],
    imageThumbs: [
      thumb("pool-beach", "pool-towel"),
      thumb("pool-beach", "beach-towel"),
    ],
    featured: true,
    tags: ["pool", "beach", "resort"],
    alt: "Pool towel for resort and leisure hospitality collections",
  },
  {
    id: "logo-towel",
    slug: "logo-towel",
    name: "Custom Logo Towel",
    category: "towels",
    subcategory: "logo-custom-towels",
    shortDescription: "Branded towel programme for corporate, hospitality and private-label buyers.",
    description:
      "A custom-branded towel programme — woven label, embroidery or heat-transfer logo application, developed to your specification for corporate gifting, hospitality amenity or private-label ranges.",
    material: "100% cotton terry",
    gsm: "[Confirm with Mundada]",
    size: "[Confirm with Mundada]",
    colors: ["[Confirm with Mundada]"],
    construction: "Custom branding — woven, embroidered or heat-transfer",
    applications: ["Hospitality", "Corporate", "Private label"],
    customization:
      "Logo, label, colour, size and packaging development available on request.",
    moq: "[Confirm with Mundada]",
    images: [
      image("logo-custom", "logo-towel"),
      image("logo-custom", "logo-towel-detail"),
    ],
    imageThumbs: [
      thumb("logo-custom", "logo-towel"),
      thumb("logo-custom", "logo-towel-detail"),
    ],
    featured: true,
    tags: ["logo", "custom", "private-label"],
    alt: "Custom logo towel for branded hospitality and private-label programmes",
  },
  {
    id: "cotton-bath-mat",
    slug: "cotton-bath-mat",
    name: "Cotton Bath Mat",
    category: "towels",
    subcategory: "bath-mats",
    shortDescription: "Tufted cotton bath mat for hospitality, spa and retail bathrooms.",
    description:
      "A tufted cotton bath mat developed for hospitality and spa bathroom programmes, with a non-slip backing suited to repeat commercial washing.",
    material: "100% cotton tufted pile",
    gsm: "[Confirm with Mundada]",
    size: "[Confirm with Mundada]",
    colors: ["White", "Ivory", "[Confirm with Mundada]"],
    construction: "Tufted cotton pile, non-slip backing",
    applications: ["Hospitality", "Spa", "Home"],
    customization:
      "Custom size, colour, backing and private-label packaging available on request.",
    moq: "[Confirm with Mundada]",
    images: [image("bath-mats", "cotton-bath-mat")],
    imageThumbs: [thumb("bath-mats", "cotton-bath-mat")],
    featured: false,
    tags: ["bath-mat", "bathroom"],
    alt: "Cotton bath mat for hospitality and spa bathroom collections",
  },
  {
    id: "kitchen-napkin",
    slug: "kitchen-napkin",
    name: "Kitchen Towel & Napkin",
    category: "towels",
    subcategory: "kitchen-napkins",
    shortDescription: "Absorbent cotton kitchen towel and napkin set for F&B and retail.",
    description:
      "A kitchen towel and hand-napkin set in absorbent cotton, developed for food & beverage operations and retail kitchen ranges — durable through frequent washing.",
    material: "100% cotton",
    gsm: "[Confirm with Mundada]",
    size: "[Confirm with Mundada]",
    colors: ["White", "Ivory", "[Confirm with Mundada]"],
    construction: "Cotton terry / waffle weave",
    applications: ["F&B", "Retail", "Home"],
    customization:
      "Custom weave, colour, labels and packaging available on request.",
    moq: "[Confirm with Mundada]",
    images: [
      image("kitchen", "kitchen-napkin"),
      image("kitchen", "hand-napkins"),
    ],
    imageThumbs: [
      thumb("kitchen", "kitchen-napkin"),
      thumb("kitchen", "hand-napkins"),
    ],
    featured: false,
    tags: ["kitchen", "napkin"],
    alt: "Kitchen napkin textile from Kiran Global Exports",
  },
  {
    id: "bamboo-towel",
    slug: "bamboo-towel",
    name: "Bamboo Blend Towel",
    category: "towels",
    subcategory: "bamboo-specialty-towels",
    shortDescription: "Bamboo-cotton blend towel for spa and wellness retail ranges.",
    description:
      "A bamboo-blend towel developed for spa, wellness and eco-conscious retail ranges — the bamboo fibre content and exact blend ratio are confirmed per order.",
    material: "Bamboo blend — final composition available on request",
    gsm: "[Confirm with Mundada]",
    size: "[Confirm with Mundada]",
    colors: ["[Confirm with Mundada]"],
    construction: "[Confirm with Mundada]",
    applications: ["Spa", "Wellness", "Retail"],
    customization:
      "Custom composition, size, colour and branding available on request.",
    moq: "[Confirm with Mundada]",
    images: [image("bamboo-specialty", "bamboo-towel")],
    imageThumbs: [thumb("bamboo-specialty", "bamboo-towel")],
    featured: false,
    tags: ["bamboo", "specialty"],
    alt: "Bamboo specialty towel for spa and wellness collections",
  },
  {
    id: "terry-gloves",
    slug: "terry-gloves",
    name: "Terry Spa Gloves",
    category: "towels",
    subcategory: "terry-accessories",
    shortDescription: "Terry glove accessories for spa, hospitality and personal-care ranges.",
    description:
      "Terry glove accessories developed for spa, hospitality and personal-care collections — sold individually or as part of a set with matching towels.",
    material: "100% cotton terry",
    gsm: "[Confirm with Mundada]",
    size: "[Confirm with Mundada]",
    colors: ["White", "Ivory", "[Confirm with Mundada]"],
    construction: "Cotton terry",
    applications: ["Spa", "Hospitality", "Wellness"],
    customization:
      "Custom size, colour, branding and set packaging available on request.",
    moq: "[Confirm with Mundada]",
    images: [image("accessories", "terry-gloves")],
    imageThumbs: [thumb("accessories", "terry-gloves")],
    featured: false,
    tags: ["accessories", "spa"],
    alt: "Terry glove accessory for spa and hospitality collections",
  },
];

const categorySlugMap = {
  "hotel-towels": "hotel-hospitality",
  "jacquard-towels": "jacquard",
  "waffle-towels": "waffle",
  "zero-twist-towels": "zero-twist",
  "dobby-border-towels": "dobby-border",
  "pool-beach-towels": "pool-beach",
  "logo-custom-towels": "logo-custom",
  "kitchen-napkins": "kitchen",
  "bamboo-specialty-towels": "bamboo-specialty",
  "terry-accessories": "accessories",
};

export const towelProducts = albumTowelProducts.map((product) => ({
  ...product,
  subcategory: categorySlugMap[product.subcategory] || product.subcategory,
  image: product.images[0],
  gallery: product.images,
}));

export function getTowelCategories() {
  return [...new Set(towelProducts.map((product) => product.subcategory))];
}
