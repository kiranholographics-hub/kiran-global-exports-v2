// ---------------------------------------------------------------------------
// Post-build prerendering script
// ---------------------------------------------------------------------------
// This project is a Vite + React Router SPA — not Next.js. Vite has no
// built-in SSR/SSG toggle, so "turn on SSR" isn't a one-line setting here.
// This script gets the same practical result a different way: after
// `vite build`, it visits every page we want Google to index in a real
// headless browser, waits for React (and the SEO component, which sets
// title/meta/canonical via useEffect) to finish rendering, and saves the
// resulting fully-rendered HTML as a static file at that route's path.
//
// The result: a crawler requesting /about gets real, complete HTML
// immediately — no JavaScript execution required on Google's end — while
// real visitors still get the normal fast client-side SPA experience
// (index.html's own JS bundle rehydrates over the static markup).
//
// Usage:
//   npm install --save-dev puppeteer
//   npm run build
//   node scripts/prerender.mjs
//
// Or wire it up as a single step: add to package.json
//   "postbuild": "node scripts/prerender.mjs"
// so it runs automatically every time `npm run build` finishes.
//
// This machine could not verify this script end-to-end (no browser
// binary download available in this sandbox) — run it locally and check
// the printed output before trusting it in production.
// ---------------------------------------------------------------------------

import { fileURLToPath } from 'node:url';
import path from 'node:path';
import fs from 'node:fs/promises';
import http from 'node:http';
import handler from 'serve-handler';
import puppeteer from 'puppeteer';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DIST_DIR = path.join(__dirname, '..', 'dist');
const PORT = 4173;

// Only the pages we actually want Google to index (must match
// public/sitemap.xml and each page's <SEO noindex> setting — prerendering
// a noindexed page is harmless but pointless, so keep this list in sync
// rather than trying to crawl every route automatically).
const ROUTES_TO_PRERENDER = [
  "/",
  "/about",
  "/linen",
  "/export",
  "/custom",
  "/contact",
  "/privacy-policy",
  "/terms-and-conditions",
  "/towels/bath-towels/bath-towel",
  "/towels/bath-sheets/bath-sheet",
  "/towels/hotel-towels/hotel-border-towel",
  "/towels/jacquard-towels/jacquard-towel",
  "/towels/waffle-towels/waffle-weave-towel",
  "/towels/zero-twist-towels/zero-twist-towel",
  "/towels/dobby-border-towels/greek-border-towel",
  "/towels/pool-beach-towels/pool-towel",
  "/towels/logo-custom-towels/logo-towel",
  "/towels/bath-mats/cotton-bath-mat",
  "/towels/kitchen-napkins/kitchen-napkin",
  "/towels/bamboo-specialty-towels/bamboo-towel",
  "/towels/terry-accessories/terry-gloves",
  "/rugs/hotel-bath-rug",
  "/rugs/heritage-decorative-rug",
  "/rugs/spa-hospitality-rug",
  "/rugs/home-comfort-rug",
  "/rugs/custom-branded-rug",
  "/linen/towels-bath/classic-bath-linen-set",
  "/linen/towels-bath/hotel-robe-towel-bundle",
  "/linen/bed/cotton-bedsheet-set",
  "/linen/bed/duvet-cover-pillow-set",
  "/linen/table-dining/jacquard-table-runner-set",
  "/linen/table-dining/cotton-tablecloth",
  "/linen/kitchen/kitchen-towel-set",
  "/linen/kitchen/apron-oven-mitt-set",
  "/linen/home-textile/cushion-cover-set",
  "/linen/home-textile/cotton-throw-blanket",
  "/linen/custom-private-label/private-label-linen-programme",
  "/linen/custom-private-label/custom-logo-linen-development",
 ];

function startStaticServer() {
  return new Promise((resolve) => {
    const server = http.createServer((req, res) =>
      handler(req, res, { public: DIST_DIR, cleanUrls: false })
    );
    server.listen(PORT, () => resolve(server));
  });
}

async function prerenderRoute(browser, route) {
  const page = await browser.newPage();
  const url = `http://localhost:${PORT}${route}`;

  await page.goto(url, { waitUntil: 'networkidle0', timeout: 30000 });

  // The SEO component sets <title>/<meta>/<link rel="canonical"> inside a
  // useEffect, which runs after the initial paint — wait for the
  // canonical link to actually exist so we don't capture the page before
  // that effect has run.
  await page.waitForSelector('link[rel="canonical"]', { timeout: 10000 }).catch(() => {
    console.warn(`  ! canonical link never appeared for ${route} — captured anyway, please check manually`);
  });

  // Small settle delay for any last animation/layout-affecting JS.
  await new Promise((r) => setTimeout(r, 300));

  const html = await page.content();
  await page.close();
  return html;
}

async function writeRouteHtml(route, html) {
  // "/" -> dist/index.html (already exists from the build, this overwrites
  // it with the prerendered version). "/about" -> dist/about/index.html so
  // a static file server naturally serves it for that exact path.
  const outDir = route === '/' ? DIST_DIR : path.join(DIST_DIR, route);
  await fs.mkdir(outDir, { recursive: true });
  await fs.writeFile(path.join(outDir, 'index.html'), html, 'utf-8');
}

async function main() {
  try {
    await fs.access(DIST_DIR);
  } catch {
    console.error('dist/ not found — run `npm run build` first.');
    process.exit(1);
  }

  console.log('Starting local static server for dist/ ...');
  const server = await startStaticServer();

  console.log('Launching headless browser ...');
  const browser = await puppeteer.launch({ headless: 'new' });

  let failed = 0;
  for (const route of ROUTES_TO_PRERENDER) {
    try {
      console.log(`Prerendering ${route} ...`);
      const html = await prerenderRoute(browser, route);
      await writeRouteHtml(route, html);
      console.log(`  ✓ saved dist${route === '/' ? '/index.html' : `${route}/index.html`}`);
    } catch (err) {
      failed += 1;
      console.error(`  ✗ failed to prerender ${route}:`, err.message);
    }
  }

  await browser.close();
  server.close();

  if (failed > 0) {
    console.error(`\n${failed} route(s) failed to prerender — check the errors above.`);
    process.exit(1);
  }
  console.log('\nDone. Every route above now has real HTML in dist/, ready to deploy.');
}

main();
